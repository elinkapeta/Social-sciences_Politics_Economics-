<img src="./anpt5e3l.png"
style="width:2.90625in;height:0.73181in" />

> *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96*
>
> **From** **Participant** **Observation** **to** **the**
> **Observation** **of** **Social** **Distancing:** **Teaching**
> **Ethnography,** **Blogging** **and** **University** **Education**
> **during** **the** **Pandemic**
>
> Eleni Sideri¹, Elina Kapetanaki²
>
> *¹University* *of* *Macedonia,* *Greece,* *²University* *of*
> *Macedonia,* *Greece.*

**Abstract:**

This article draws from a collaborative blog *Our* *Quarantine*
*Diaries* created during the first COVID-19 confinement in Greece in
2020. In a context of sharing, participation, and solidarity, the blog
aimed to facilitate an online/synchronous shared space between students
and educators during this period of social distancing. The blog was a
way to experiment and reflect through an ethnography of the ‘every day’
to capture aspects of our experiences in quarantine and communicate them
to one another. Through the blog we attempted to trace how participant
observation can help us understand this new condition of social
distancing, using (self)observation, memory and imagination to grasp
experience. The result was eighteen multimodal recordings consisting of
visual, sonic, musical and verbal information. By the end of the
process, we realized that the experiment helped us, if not to overcome,
then to engage and to a degree, ‘exercise’ the fear of this new type of
‘evil’ through digital communication, ethnographic observation and
anthropological analysis. In this article, we reflect on the digital
aspects of the affective and emotional modalities of teaching/doing
ethnography via the use of *Our* *Quarantine* *Diaries* blog during this
unusual time.

**Keywords:** pandemic, social distancing, digital anthropology,
teaching ethnography, blog.

**Introduction**

> …ethnography is the practice developed in order to bring about
> empirical-based knowledge about human worlds according to certain
> methodological principles, the most important of which is
> participant-observation ethnographic fieldwork1. *The* *Cambridge*
> *Encyclopedia* *of* *Anthropology* (2018)

For years, the discipline of social anthropology has been identified
with its method of ethnographic fieldwork, used to distinguish it from
other similar social sciences like sociology. Although today, this is no
longer the case, both fieldwork and participant observation remain
significant to what social anthropologist do, despite also being used by
several other social sciences (Mills and Ratcliffe, 2011, p. 1-18).

The pandemic put a tombstone on many ethnographic projects, and it
forced others in progress to change their research design. Extra burden
was put on researchers to take into account risks related to COVID-19 in
the statements to their institutions’ research committees. Besides
research, teaching and learning social anthropology also had to change,
as online teaching became the ‘new normal’ in university education
wholly or in hybrid forms. For years, there has been a demand for
innovative methods of teaching in our pedagogies and when the pandemic
emerged, we were forced to become creative. However, many questions were
raised. How could social anthropologists teach their methods in
confinement or via specific educational platforms? How could they teach
what fieldwork was when the field turned hostile for human life?2

Drawing from the first long confinement applied in March 2020 in Greece,
our paper will show how the pandemic made us think outside the box and
help to share a moment of intimacy – although at a distance – with our
students through the creation of the *Our* *Quarantine* *Diaries* blog.
This participatory project in which ourselves, as well as some of our
students took part, was a space for communal reflection, a mediatized
and mediated experiment aiming to capture our experiences in quarantine
and communicate them to one another.

1 https://www.anthroencyclopedia.com/entry/ethnography

2 Social anthropologists do fieldwork in hostile environment, for
example, war zones but the pandemic and the security measures taken at a
global level made not only research but even traveling impossible.

> 86

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

Those blogs reflected not only on the social conditions of our lives,
such as class, gender, or position, but also gave an opportunity to more
deeply reflect on our procedures of teaching and doing ethnography in
university.

In this paper, we firstly discuss how our discipline addressed
challenges regarding ethnographic methods and fieldwork before COVID-19.
Drawing on anthropological practice during crisis such as the World
Wars, we explore how the idea of ‘social distancing’ from the field was
not something new to the discipline. We go on to consider the
significance of the linguistic turn and how anthropologists
understanding of ‘experience’ can help us address the exigencies
regarding field work during the COVID-19 crisis. In the second section,
we discuss the shared blog experiment that we did with our students,
addressing the ways it helped us to create bridges with them during
social distancing. We understand blog making as a way of dealing with
confinement. In the final part, we discuss how the different blog
entries and the different modalities used captured the impact of the
pandemic at this moment of time. We end by describing the pedagogical
benefits of our work, and the conclusion we drew from what our students
and ourselves felt during this experiment and how it gave us ideas to
strengthen and pluralise our teaching methods.

**Crises** **and** **Adaptation** **in** **Ethnographic** **Fieldwork**

> How differently a man imagines his life from the way it turns out for
> him! B. Malinowski (1989 \[1967\], p. xxv)

The sentence above marks the arrival of a young scientist to Papua. What
young Bronislaw Malinowski wrote in the opening pages of his diary was
not what he saw but how differently he had imagined his life in the
academia. In the following pages, he often made references to
imagination. Soon, after his arrival, he became prisoner of his Majesty
after the outburst of World War I, given that he was a subject of the
Habsburg Empire although ethnic-Polish. This forced confinement on the
island made him creative and resourceful, resulting to a new method of
empirical observation from a close distance. Creativity and imagination
played an important part in his work on the island. For example, he
admitted in his diary that to understand what the impact of the choice
of sexual partners was for the Trobriand society, he made comparisons
with his own life in Poland, “I imagined meetings with various Polish
men and women. If I married E.R.M., I would be estranged from
Polishness” (Malinowski, 1989 \[1967\], p. 174). Observing the
experience of Trobrianders forced him to bring back memories and use his
imagination to develop a cultural comprehension. Similarly, in his
seminal monograph, *The* *Argonauts* *of* *the* *Western* *Pacific*
(Malinowski, 2002 \[1922\], p. 13), he invited the reader, “Imagine
yourself suddenly set down surrounded by all your gear, alone on a
tropical beach close to a native village”.

Times of crises, such as World Wars, often demands creative solutions.
However, if we consider what Malinowski did during his fieldwork and
compare it to what his predecessors used to do, we could understand
better the role of imagination in ethnography. In the empirical
positivist framework of the 19th century, as Lienhardt (2003) argued,
social anthropology was trying to trace the universal laws that
determined the organisation of human societies. This aspiration was done
through mediation and not through physical presence in the field, for
example through bibliographical research, questionnaires carried to the
places of interest by merchants, missionaries, or other categories of
travellers to Africa or Asia. Gathering and providing information
thorough this type of description was one thing, but there was also the
works of imagination. Malinowski underlined the role of imagination in a
letter he wrote to James Frazer, the author of *The* *Golden* *Bough*
(1990 \[1890\]) and a leading figure of anthropology of those early days
not only in Britain. In that letter, Malinowski commented on how
Frazer’s vivid description helped him get a grasp of the tribal life
described in Frazer’s book.

> I remember how helpful it was to find in your T&E \[Totemism and
> Exogamy\] a picturesque account of the country where the respective
> tribes live. In fact, I found that the more scenery and ‘atmosphere’
> was given in the account, which you had at your disposal, the more
> convincing and manageable to the imagination was the ethnology of that
> district (Malinowski quoted from Thorton, 1985, p. 8).

‘Armchair anthropologists’, the term used to describe the lack of
physical contact with the field, were doing ethnography from a distance
based on available sources and accounts but also imagining the life ‘out
there’ and trying to provide their readers with accurate and vivid
descriptions. The problem with their research production was not the
descriptive accounts but the epistemology, the conviction of scientific
objectivity, lack of historical contextualisation and critical
examination of their own voice and subjectivity in the construction of
these texts. In a sense, the pandemic brought social anthropologists
back to the origins of our discipline. We were all forced to become
armchair anthropologists. But instead of an armchair in a library at
Cambridge or Oxford, we had an

> 87

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

office-desk-chair in front of a computer; and instead of trying to
deduct universal laws, we tried to position our experience within the
process of situating, representing and writing our research.

After a decade from Malinowkski’s fieldwork in the Trobriand islands, at
the end of yet another global crisis of World War II, two female
anthropologists, Ruth Benedict and Margaret Mead, were asked to study
“culture at a distance”. The need to ‘know the enemy’ made ethnographic
knowledge an asset both during and after the war period to understand
geopolitical change.

> In 1944, I was assigned to study Japan. I was asked to use all the
> techniques I could as cultural anthropologists to spell out what the
> Japanese were like. (..) As a cultural anthropologist, in spite of
> these major difficulties, I had confidence in certain techniques and
> postulates which could be used. (Benedict, 1946, p. 164, 190).

Benedict, student of Franz Boas and a leading American cultural
anthropologist, was the main advocator of gestalt (personality and
national character psychology) in social anthropology. During World War
II, the Department of the War asked for her expertise in the case of
Japan. As Benedict discussed in the introduction of the book, *The*
*Chrysanthemum* *and* *the* *Sword* (2005, \[1946\]), the ‘assignment
Japan’ was not based on field work. Instead, as she admitted the
numerous writings of westerners who travelled or live in Japan before
the war were valuable sources of information. Furthermore, she watched
Japanese movies and often watched these films with Japanese living in
the USA so they could share their insights about these movies with her.
She also compared her research questions with ethnographies from the
same Pacific region to reveal connections of “isolated bits of culture”
(2005, \[1946\]), p.255), which the untrained eye would have dismissed,
as part of a wider cultural pattern and behaviour. Benedict went on to
inaugurate a seminar at Columbia University to teach “wartime
techniques” to study cultures from a distance (Price 2016, p. 99-101).
Rhoda Metreaux and Margaret Mead followed up with studying culture at
distance though partial clues (linguistic, literary, filmic, artistic,
interviews, games, slang etc.) (Mead and Meteaux, 1949, p. 3-57).
Throughout these various crises then, anthropologists have been cut off
from their field sites. These emergencies forced ethnographers to adapt
to more ‘distanced’ methods, but it did not impede anthropological
research.

In the 1960/1970s, another crisis was in the making, this time ‘from
within’. The ‘linguistic turn’, the new understanding of reality as
constructed through linguistic and cognitive categories, generated a
reconsideration of the production of ethnographic knowledge. This
pivotal shift had an impact both in the ways social anthropologists
understood experience and later on, in the way they practiced
ethnographic methods and writing. Jason Throop (2003) argued that
fieldwork and participant observation helped the ethnographer access the
singularity of the moment – the experience of a unique encounter between
the researcher and the field, where their senses could grasp words,
images, sounds, smells, touch, tastes *and* where they developed
emotions or affective intuitions of what, how and when the ‘local’ and
the ‘global’ was produced.

In the past, within a structuralist framework, the ‘singularity’ of the
fieldwork experience was considered the vehicle through which the
invisible and underlying structures of culture and human thought could
be revealed. However, in that period, social anthropologists did not
look for universal laws and systems of thoughts. Instead, both schools,
the British Symbolic Anthropology and the American Interpretive
Anthropology considered cultures as networks of interwoven symbols and
meanings. The leading figures of both schools, Victor Turner for the
former and Clifford Geertz for the latter, tried to redefine the notion
of experience.

For both, experience was of a fleeting and transient nature. What the
ethnographer’s experience can grasp was lost and became mediated (thus
distanced) moments, immediately after its observation. In this
understanding, sensory impressions were immediately filtered when we
take notes, write diaries, make sketches and drawings, take pictures or
filming. In other words, the raw experience of the field turns to a
‘signifying’ act for Geertz and a ‘structured’ one for Turner in order
to create ethnographic knowledge. For both, experience cannot be reduced
but is part of a circuit of symbols and meanings; “all experience is
construed experience*”* (Geertz quoted from Throop, 2003, p. 226). In
this way, ‘being there’ is not a guarantee of understanding cultures. It
is only a small, but significant, part of the methods that social
anthropologists could use. In the same period of time, the development
of cultural studies, shifted the attention to studying culture without
using field work (Longhurst et al, 2016). The emergence of multimodality
challenged logocentrism in social sciences (see Kress, 2003) and its use
as a methodological tool to capture the growing mediatic and digital
mediations, challenged the pre-eminence of fieldwork.

> 88

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

This brief historical account postulated the ways social anthropology,
methodologically and theoretically, approached ‘the real’ and the way
the discipline challenged and reflected upon the empirical reality of
the ‘field’. Observation and experience from an immediate and sensorial
practice gradually became understood as a constructed and mediated
outcome of research, where imagination and memory are integral elements
of fieldwork production. Memory and imagination contributed to the
formation the ethnographer’s subjectivity and the way they produce
categories of knowledge. Furthermore, that new understanding of
experience combined with the post-colonial and cultural critique (Fisher
and Marcus, 2003 \[1986\]) gave rise to an increased sensitivity and
problematisation of ethnographic writing – writing that relied on
particular modalities of representation which contributed to the
production/construction of the ‘real’ (Clifford and Marcus, 1986). In
the last decades, digital ethnography or hybrid forms of ethnography
combining different methods of fieldwork in online research, have
created new understandings of the mutual, interwoven production of
Subject-Object (Latour, 2012 \[1993\]). As a result, the pandemic did
not find social anthropology without tools to examine this ‘new’
reality, despite the scale, duration and total impact, COVID-19 had on
our everyday life.

**Creating** **‘Our** **Quarantine** **Diaries’**

Drawing from this understanding of experience as always mediated and
mediatized, and from the prior challenges within social anthropology,
when the pandemic started, we proceeded to create a small project. Our
first year-class, *Introduction* *to* *the* *Methodologies* *of*
*Social* *Sciences,* at the department of Balkans, Slavic and Oriental
Studies, where one of us taught the formation of the anthropological
thought and methods from different schools of sociology, critical
thinking and social anthropology, and the other did lab-oriented
activities (shaping a research question, developing the research design,
academic writing etc), brought us together. When the first confinement
was enforced in Greece in March 2020, we were in the beginning of the
spring semester. In that semester, we did not share a class, but we
shared the desire to explore the ways that confinement and the enforced
social distancing affected our students. We were motivated by personal,
academic and pedagogical reasons. First, we needed to address the fears
and awkwardness we felt dealing with this unprecedented condition.
Sharing a digital space was a way to substituted what we missed the
most, going to our classes, talking to our students and colleagues. It
was a psychological support and catharsis, implying that we are here, we
the teachers, we the students, we the humans. Second, we wanted to
explore how this new space of teaching and sociality –the e-academic
space – can work in practice as an ethnographic field and space for
reflection. Third, we tried to explore how digital methods can become
embedded in the pedagogy of university teaching.

This desire urged us to create a shared blog *Our* *Quarantine*
*Diaries*. We used blospot.com because it was one of the most
accessible, easy to use platforms. In our call, which ran in English and
Greek, we asked three key questions that Our Quarantine Diaries aspired
to answer:

> • How can personal experiences, knowledge and feelings of everyday
> life in quarantine be transformed or at the same time be commonplace?
>
> • What are the aspects of our experienced reality? from home, balcony,
> self and companionship? What are the dimensions of “free time” in
> quarantine and how is the space we live and share valued?
>
> • What are the dynamics and power of capturing our experiences?*3*

We circulated the call among our department’s students at different
levels as well as among alumni. We also included the students –asylum
seekers- of Solidarity Now, an NGO we collaborated with and had been
planning a common class activity to bring together and sensitise both
groups to stereotypes, intercultural communication and volunteering,
just before the pandemic. The call ran for less than a month and we
collected 18 blog entries of various forms and content. We invited our
students and alumni to choose the way they would contribute to the blog,
stating that this could be a verbal text, a video, a series of photos,
an audio document, or a painting. We mentioned that our target was to
capture our experience during confinement without necessarily excluding
fictional aspects in blog entries. All submissions were accepted for
publication, and we did not reject any. However, we noticed that
although there was significant interest, many of the people who
responded to our first call later wrote to us that due to the increasing
burden of their work, they could not submit anything. These responses
coincided with our own observation that working from home increased our
‘office’ hours and duties as the compartmentalization between work and
private life dissolved, giving the impression that being confined at
home meant immediate availability at any time (Manokha, 2020).

3
[<u>https://ourquarantinediaries.blogspot.com/</u>](https://ourquarantinediaries.blogspot.com/)

> 89

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

The choice of a diary was not coincidental. The use of fieldwork diaries
are often the first texts where social anthropologists can process the
‘raw’ experience, the first space for mediation through memory and
cognition in which anthropological experience is constructed. Moreover,
it was a genre of writing that all students had come into contact with
as it was covered in prior compulsory anthropology classes in our
department. What our small experiment postulated, and the following
analysis will illustrate, was that 1. multimodality is much more
embedded in our realities than we expected (pictures, sounds videos,
photographs are part of students’ construction of the ‘real’ etc), 2.
the boundary between reality and fiction is much more challenged and
transgressed. The blog entries showed that fictionalised reality made
the understanding of the ‘new reality’ easier and maybe more tolerable.
Finally, creativity through which emotions vis-à-vis the cognitive
understanding of the pandemic and the ‘real’ was bought into view,
emerged as an important strategy of knowledge production.

**Analyzing** **the** **blogs**

Blog entries tried to capture and conceptualise ‘the moment’, life,
doing, feeling or imagining during confinement. At the same time, they
raised questions connected to the potential relations between realism
and fiction as part of our ethnographic recordings. Actually, these were
some of the questions we asked ourselves at the beginning of the first
COVID-19 confinement in Greece. It was the same questions that we tried
to raise and analyse through our common digital project. “Our Quarantine
Diaries” as a digital shared archive contained a mosaic of different
voices and perceptions of experience with regard to the quotidian in
confinement. However, these entries and their analysis were produced at
the very beginning of the quarantine. It is possible that more recent
descriptions about confinement would lead to totally different
conclusions. For archival use, nevertheless we believe that our
experiment although short and fragmented gives a sense of that
challenging moment. There are descriptions about the shock of living in
confinement, displays of fears, practices of daily lives in quarantine,
as well as recordings of anticipation for our world to change. Such
material could serve as a supplemental archive that can be
studied/analyzed in the future together with other recordings about the
experience of the Covid-19 pandemic. What follows is our initial
analysis of the blog entries, which is divided in two broad categories:
how people write and what people write. The repetition of certain topics
and manners of description led us (Sideri and Kapetanaki) to aggregate
blog entries into style categories, but how do we comprehend these
multimodal texts produced in the blog?

In his work “*Emergent* *forms* *of* *life:* *Anthropologies* *of*
*Late* *or* *Postmodernities*”, Fischer (1999) talks about different
perspectives on recording, analyzing and expressing the fragilities of
contemporary via the poetic procedure of ethnography. According to him,
those virtual worlds of cyberspace, as well as films “*have* *become*
*increasingly* *strong* *sinews* *of* *our* *social* *worlds*”. Within
this article, those different ways of recording fragments of the
contemporary life in quarantine are described as different *styles* of
the blog entries. Thus, blog style can be textual, visual, sonic or
hybrid and constitute glimpses of what is conceived as ‘real’ (Clifford
and Marcus, 1986) in confinement. According to Fischer (1995), through
such material, consisting of visual, sonic, musical and verbal
information, it is possible to describe aspects of the everyday in a
more “complicated” and less “linear” way. The results of which differs
from the result that would have been achieved if the recording was based
only on the written word. We consider this multimodal form of blog
entries as a poetic manner for the bloggers to express their subjective
perceptions of pandemic, particularly when it comes to feelings and
ideas that are not easy to verbally record. Importantly, though we
describe them separately, blogs entries may fall across one or more
styles.

**How** **people** **write:**

**a.** **Reflection-diaries**

Reflection-diaries are descriptions and re-productions of the everyday
that were recorded in different combinations and variations. Here, we
follow the thoughts of the blog writers, the internal dialogues they
have with themselves, fragments of their fears, needs and questions for
the future. These confessions in confinement sometimes become deeply
affective. As one of the contributors of the blog wrote, “*then* *I*
*realized* *that* *it* *was* *not* *the* *first* *time* *that* *I*
*felt* *insecure,* *since,* *due* *to* *precarity,* *insecurity*
*constitutes* *part* *of* *my* *life* *during* *the* *last* *years*”.
Sometimes, through their recordings, bloggers narrated stories about
their confrontation-encounter with illness and healing, or even about
their desire to overcome the limitations of their bodies. In other
cases, the writers described the process of communicating and meeting
again with family members after a long time.

In the reflection diaries, we meet aspects of the blog writers’ lives,
experiences and fragments of lived realities of time, space,
interactions. For example, we follow them moving from inside home to
balcony, and from loneliness to sharing, in procedures reflected through
different modalities. At this point, self-referentiality becomes a major
voice in the blog’s recordings. As Madianou (1998, p.367) stated,
reflexivity refers to a process returning to

> 90

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

oneself. This happens when researchers studing culture and possible
“others”, finally result in examining the familiar, their own exercise
of power and responsibilities. This is why, some of the blog’s
contributors asked why and how this or that happened in regard to the
pandemics. In that sense, confinement, according to their voices, was
thought to be “*our* *chance* *to* *realize* *who* *we* *are*”.

In that way, reflexivity becomes a way for one to talk and visualise
oneself in this world, while in the blog, this Self is described as a
“*field* *of* *chances*”, “*a* *better* *place* *to* *live* *in* *the*
*future*”, or “*a* *place* *that* *is* *fading*”. As one of the writers
states, confinement could be our last chance to realise that “*a*
*‘belle* *epoque’* *is* *being* *demolished*” and it is our own
responsibility now to act.

There were eight reflection-diaries entries. Five of them were written
by women, while three were written by young men who were at the time
seeking political asylum from Greece.

> **b.** **Fictionalised** **diaries**

Some of the blog writers highlighted the need to reflect upon the style
of our writings. The challenges and the need to reconsider the
scientific agenda of ethnographic writing regarding “objective”
knowledge through the genre of realism was something postulated in the
‘crisis of representation’ in the 1980s. Drawing from that we traced the
anthropological interrelations with fiction in at least four of the
contributions to our blog.4

Those fictional diaries sometimes narrated stories of people enclosed in
small apartments at the center of a big city, or maybe told stories of
people returning to small towns, or to the villages they were born in.
We could not draw conclusions regarding the exact geographic location of
these personal places, but this was not significant. The importance must
be placed on the often-hypochondriac attitudes and practices and the
routines of “producing” spatial distance, in order to be protected from
the virus, to feel secure from the danger of the pandemic, that mattered
the most in the construction of these ‘safe’ places.

In one of these stories, we had a snapshot of the life of two women at
home. One of them was old and not able to move outdoors easily. She
could hardly see the sea from her balcony whenever she felt strong
enough to move outside her room. In the story of illness and old age and
the pandemic, we can trace the conditions, due to certain medical
reasons in the narrated story, that our lives can be found on a
permanent quarantine, restriction and surveillance. Then, quarantine
seemed to refer to the confinement within the limits of a human body
that cannot or should not move. Making this comparison the blog entry
transformed the pandemic to an embodied experience from which memory
could provide a testimony of endurance and survival.

Here, the personal and internalised knowledge of the writer seemed to
abolish the borders between real and fictional. Sometimes both
anthropology and literature may have a common target. In both cases,
writings may aim to bring to light symbols of everyday routines that
give meaning to human lives. The writer underlined that the boundaries
separating the genres of speaking, writing and recording of the
manifestations of the ‘everyday life’ are not anymore static and
entrenched, rather flexible and creative.

**c.** **Visual-Stories**

Eight recordings of the blog are visualised. These included visual
stories of a beauty routine under the circumstances of confinement, and
stories displaying time passing indoors while playing with the kids,
drinking coffee, washing one’s teeth, or doing muscle-strengthening
activities. Other stories visualised aspects of virtual communication
while in quarantine.

This multimodal material takes the form of information that is given
through collections of photos, videos, music, and texts that could take
us to the homes and villages, yards, fields and streets that the blog's
contributors captured with their camcorders and cameras. It is this
multimodal information of the everyday on the internet that can capture
fragments of the desires, thoughts and communications of internet users.
At the same time, according to Athanasiou (2004) and the theory of
constructivism, bloggers are actors who may invent aspects of themselves
and their lives through internet use and narrate them in a way that
everyday life in confinement matters to them. In the context of the
pandemic, the enforced ‘new real’ led many of us to reinvent not only
ourselves but also the ‘everyday’.

4The possible connection of anthropological writings with fiction was
put forward in the context of the “Crisis of Representation” (Marcus and
Fischer, 1986). It was the uncertainty of capturing the lived experience
and interpreting social condition that criticized the value of realism
in the anthropological writings.

> 91

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

> **d.** **Hybrid** **Contributions**

Visual stories may simultaneously be reflective and fictional. In the
blog there are five hybrid entries that capture, in a fragmented way,
aspects of our lives in the first period of quarantine in Greece. They
lead us to reflect upon the concepts of time and space, working
conditions, studies and free time in confinement. In general, while
reading the texts, looking at the photos or watching the videos, one may
realise that we move away from a crude realistic
self-reflection/self-observation of auto-ethnography (Hastrup, 1992).
Capturing the everyday appears to be an experiment combining narration
and personal experience with fiction, history, and routines that
symbolically matter to us. These different but interconnected blog
styles indicated the intense ways multimodality has entered the
(re)production and (re) construction of selves, challenging the
boundaries reality and fiction.

‘Our quarantine diaries’ consequently raised many questions with which
anthropological theory is already familiar, but ones we continue to
revisit. More precisely, regarding the significance of one’s physical
presence during the fieldwork and what should be considered ‘real’, and
how in turns we conseptualise the word experience. Thesereturning
dilemmas triggered by Covid-19 may foreshadow another crisis for the
anthropological theory and practice, or they may simultaneously reveal a
procedure of ethnographic renewal (Athanasiou, 2004).

**What** **people** **write:**

As per the stylistic modalities of expression in the blog, what people
write about is related to the re-presentation of oneself and the
narration of his/her experiences of the everyday. These narrations, take
place in the cultural and historical context of confinement and produce
aspects of that experience as perceived by the blogger. According to
Bruner (1986, p. 4-5) experiences are not mere data but, drawing on
Dilthey (1976), they are at the same time emotions and expectations.
Thus, in sharing experience, bloggers are sharing these personalised
realities. Four key themes emerge in what is described by the content of
the blogs.

> **a.** **Curating** **the** **quotidian/the** **self** **as**
> **actor**

In Quarantine Diaries, the contributors are actors curating their own
perspectives of the everyday. One of the writers states that “*it* *may*
*be* *sound* *funny* *but* *I* *enjoy* *staying* *indoors* *\[..\]* *I*
*play* *the* *trumpet,* *sing* *and* *watch* *movies.* *In* *general,*
*we* *practice* *whatever* *we* *didn’t* *have* *the* *time* *to* *do*
*before.* *This* *is* *how* *time* *passes* *by* *creatively* *for*
*me*”. Other contributors narrate how they learnt Greek. Another asks
themselves if they only wait for better days to come. While others
sterilize everything or take care of themselves and others, so as to be
healed or recover from chronic health issues.

Here the descriptions in regard to the curation of the quotidian
resemble an autobiographic, confessional and autoethnographic text that
communicates to us an internal, and, sometimes, fictional world. It is
the time that space does not bear specific dimensions, nor can be
limited in the context of a house. Rather it is creatively determined by
one’s activities in confinement. Then, quarantine may be thought to be a
“blessing”, a kind of “science fiction”, or an “Orwellian scenario”.

**b.** **A** **creative** **self** **is** **being** **revealed**
**through** **Irony** **and** **Humour**

There are also humoristic displays of the everyday depicting a
depository of toilet papers located under the bed of the protagonist of
a video. In another case, the photograph of one of the blog’s narrators
is being displayed next to a collage of logos of new media platforms,
such as Zoom, Facebook, frequently used in communication during
confinement. In the same collage of pictures, the places that one should
definitely visit during the summer of 2020 are written as the platforms
of electronic communications displayed in the constructed image.

On another picture in the blog, the protagonist of the scene is a pair
of plastic gloves with polished fingernails. Plastic gloves are the
product used the most widely during the first months of the quarantine
in Greece. In this picture, there is a simultaneous display of a beauty
“ritual” in confinement, together with the presentation of a variety of
tools that may be used for disinfection, thus protecting from COVID-19.

In some video-narrations we may trace a playful kind of video editing
that is fast, ironically revealing an everyday life condition that seems
to dispel fear and play with the unknown, while in other
video-narrations the choice of music used is composed of alternating
sounds. These sounds may be similar to a horn, while the sound suddenly
shifts to a major scale expressing joy and satire.

> 92

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

**c.** **Eschatology:** **The** **end** **of** **the** **world** **as**
**we** **know** **it**

For some of the “Our quarantine diaries” blog writers, confinement
signals the end of the world as we know it. One of the writers, who
lives and works in Central Europe, mentioned, the balance in her work
was interrupted after the first new reports of the pandemic. Some of her
colleagues asked for permission to work from home so as to avoid being
contaminated with COVID-19. Simultaneously, other colleagues were
neglecting the new virus and were fearlessly laughing. This was a period
where quarantine seemed to be just an unusual solution for protecting
people from the virus, re arranging professional habits and creating new
divisions (the fearful vs. the fearless). Then, the writer mentions that
“*Here* *comes* *the* *disaster,* *in* *a* *totally* *unexpected*
*way*”. Her colleagues continued laughing in ignorance at the breaking
news in regard to the virus, while she, having access to reports from
the Greek media, was wondering whether their ignorance reflected
“arrogance” or was just a “prophet of doom”.

In other cases, the end of the world was revealed as part of fading
cities that may never have existed, at least in the way the specific
blog writer had wished for. It was also portrayed in a series of photos
entitled “*the* *melancholy* *of* *catastrophe*” drawn from the
eschatological film of Lars von Trier, *Melancholia* (2011). In another
case, the difference between the condition of free movement and life in
quarantine, was highlighted through the montage of video scenes from
media reports regarding the pandemic showing beaches full of people,
followed by empty streets, where the only visitors are wild animals or
lonely runners.

Other writers state that the end of the world as we know it is the
chance of humanity to create a “*better* *world,* *self,* *or* *energy*
*footprint* *on* *our* *planet*”. There are also critical recordings on
the neoliberal state, connecting affect with experiences in confinement,
captured in texts, photos, videos – including video editing, which
reflects insecurity, precarity and crisis. Then, possibly our angry Self
shouts, in the same blog-entry: “*Please* *don’t* *fuck* *up!* *Maybe*
*it’s* *our* *last* *chance*”.

**d.** **Memory** **and** **time/the** **mourning** **self**

“*What* *about* *remembering* *what* *was* *left* *behind?* *Quarantine*
*brings* *us* *face* *to* *face* *with* *our* *mourning”.* Some of the
blog writers mourned over previous life conditions that were left
behind. They compared the past to the present and shared fragments of
their memories. Some referred to their previous health condition, which
was experienced similar to a confinement, but it was not so restrictive
to their activities, others referred to loved ones that had passed away,
or to cities that they are not allowed to visit any more.

Some of the writers confess their adaptation to stillness, writing,
*“It* *is* *not* *coincidental* *that* *the* *etymology* *of* *the*
*word* *“quarantine”* *already* *gives* *an* *indication* *regarding*
*the* *movement.* *It* *indicates* *cultural* *practices* *of*
*isolation,* *deprivation* *and* *excess* *of* *the* *established*
*conditions* *of* *life*”. Then, this forced immobility may become a
source of sorrow, or a state of life that they desire to overcome.

In such cases, according to Bruner (1986, pp 4-5), memory makes an
interesting connection between experiences, narration, and time, while
people may highlight, according to their own experiences, specific
entities of time. Thus, their narrations related to their experiences
and what is meaningful to them turn to meaning memories. In this manner,
as states, memory becomes a way in order one to deal with the past.
Eventually, memory seems to constitute a means to interpret
circumstances and deal with oneself, especially in critical moment like
mourning where identities seem to become reconstituted (Lambek, 1998, pp
106-127).

**Pedagogical** **benefits,** **or** **some** **thoughts** **as**
**Conclusion**

Discussing with one of the participants in “Our Quarantine Diaries”, she
told us*,* *“I* *was* *mortified* *because* *of* *that* *situation*
*and* *because* *I* *had* *a* *similar* *experience* *due* *to* *a*
*health* *problem.* *The* *call* *woke* *me* *up* *and* *reactivate*
*me”.*

The nurturing of ethnographic research and writing is a common target
among the anthropological lessons offered in our Department. To that
end, during that first long confinement applied in Greece due to
covid-19 pandemic, we and some of our students experimented with
ethnographic writing via the creation of an anthropological digital
diary, named ‘Our quarantine diaries’ blog. Our target was to record
through a collaborative blog, our shared and individual on the
experiences of the pandemic. Although our blog, as a modality of
ethnographic recording, was not used as a source for further analysis
with our students, it provided a basis for us to reflect on our future
practices for teaching and doing ethnography. For some students the
experiences served as a catalyst for further engagement. One used it as
an an energy boost to “wake up” and use

> 93

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

writing as action. Another joined another class and submitted a graphic
reflective diary as a semester assignment. A third MA student joined the
Huffington Post-Greece and follows blogging through investigative
journalism. In a sense, our blog played different roles for participants
depending on the life paths of each one of us and exceeded our
expectations.

In a symposium organised by the University of Amsterdam in 2011 on
subjectivity and ethnography, the organisers, Athena Mclean and Annette
Leibing, called for the need of an ethnography “as a way of gaining
personal knowledge and understanding ourselves via the roundabout way of
the other” (van der Geest, Gerrits, Aaslid, 2012, p. 6). Ethnographic
methods urge us first to scrutinize and face the prejudices involved in
the formation of the ‘Self’ and then, to understand the ways these
prejudices shape the process of Othering. Moreover, the impact of
ethnography can have long-term results as it forces us to reconsider who
we are or what we want to do. In this sense, ethnography becomes a
process of ‘selfing’, a creation in connection to critical engagement
and not pre-constructed ideal and thus, it can have inspiring and
lasting results for our students and us as well.

We have since used this experiment (blogging) in other classes on urban
anthropology.5 From October 2022 to April 2023 both authors we will also
be working together on the creation of a collaborative digital
repository that relate to migratory/refugee flows and women’s work on
the production of clothes in the historic center of the city we both
reside (research project “Dressmakers”). Narrations of women working in
clothing industry will be recorded by us and the students of Dr Sideri
and some of them will constitute a digital repository that will be
granted to the “Refugee Museum” of Thessaloniki. Our aim is that our
ethnographic work may be part of a public anthropological knowledge
repository that can interact with the social environment we live.

According to our digital diary, we have played the trumpet, we have
cooked, mourned, studied and polished our nails, while we have felt
melancholy, insecurity, fear, or we were even ready to fight for our
last chance to change ourselves, our societies and the planet. At the
same time, we thought our cities may be collapsing, quarantine may be a
chronic condition due to a biological disease, or that now we should
surpass ourselves and be creative. Blogs turn to a space of
collaborative teaching and learning both for our students and ourselves
in terms of endurance, compassion, fear management, care, political
critique of neoliberalism. In a sense this digital space became a
momentary and contextually specific space and time of empathy, one of
the main goals of fieldwork.

Nevertheless, we understand that we may have all been included in a
certain condition, though not in the same way. Conditions of confinement
in the cases we presented above may differ due to our past and present
social positions, our class, age, and gender. Furthermore, both
educators and students were involved in a condition that they were
trying to understand what was on going. There was a need to ask why this
happened, how we can comprehend the reasons or its evolution and its
impact. To do so, we used different modalities like remembering,
mourning, exercising and reflecting our thoughts and feelings. Ιn this
unprecedented situation there may be social and spatial distancing but,
at the same time there was a need to examine it further so it could
become better understood by us. In this collective examination,
(self)observation, memory and imagination collaborated like they do in
fieldwork in order to grasp our experiences. Finally, one may say that
this highly mediative and cognitive experience is also affective and
emotional, and this may be a good starting point to teaching /doing
ethnography.

**Disclosure** **statement**

No potential conflict of interest was reported by the authors.

**References**

> Antrho-pologos.blogspot.com(2022). Ethnografiake Poli Project 2021
> \[Ethnography and the City Project 2022\]. Retrieved from
> [<u>https://anthropo-logos.blogspot.com/</u>](https://anthropo-logos.blogspot.com/)
> .
>
> Athanasiou, A. (2004). Ethografia sto diadiktioi to diadiktio
> osethnografia: dinitiki pragmatikotita kai politismiki kritiki
> \[Ethnography in internet or internet as an ethnography: Virtual
> reality and cultural critique\], *Επιθεώρηση* *Κοινωνικών* *Ερευνών*
> *\[The* *Greek* *review* *of* *social* *research\],* 115, 49-74.
>
> Benedict, R. (2005) \[1946\]. *The* *chrysanthemum* *and* *the*
> *sword:* *Patterns* *of* *Japanese* *culture*. Houghton Mifflin
> Harcourt.

5 Creation of blogs and podcasts by the students of Dr Sideri took place
as part of the course “Ethnography and the city” that Sideri teaches at
the department we collaborate.

> 94

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

> Bruner, Ε. Μ. (1986). Experience and Its Expressions. In V. Turner, E.
> M. Bruner (Eds.), *The* *Anthropology* *of* *Experience* *(pp.*
> *3-32)*. University of Illinois Press.
>
> Clifford, J., & Marcus, G. E. (Eds.). (1986). *Writing* *culture:*
> *the* *poetics* *and* *politics* *of* *ethnography:* *a* *School* *of*
> *American* *Research* *advanced* *seminar*. University of California
> Press.
>
> Dilthey, W. (1976). *Dilthey:* *Selected* *Writings.* Cambridge
> University Press.
>
> Fischer, M. (1995). Film as Ethnography and Cultural Critique in the
> Late Twentieth Century. In D. Carson, L. D. Friedman, (Eds.),
> *SharedDifferences,Multicultural* *MediaandPractical*, pp. 30-56.
> University of Illinois Press.
>
> Fischer, M. (1999). Emergent forms of life: Anthropologies of Late or
> Postmodernities. *Annual* *Review* *of* *Anthropology,* 28, 455-478.
>
> Frazer, J. G. (1990) \[1890\]. *The* *golden* *bough*. Palgrave
> Macmillan.
>
> Gefou-Madianou, D. (\[1998\] 2011). Anastohasmos, eterotita kai
> anthropologia oikoi: Dilimata kai antiparatheseis \[Reflexivity,
> diversity and indigenous anthropology: Dilemmas and controversies\].
> In D. Gefou-Madianou (Ed.), *Anthropologiki* *theoria* *kai*
> *ethnografia,* *Syghrones* *Taseis* *\[Anthropological* *Theory* *and*
> *Ethnography:* *New* *Perspectives\],* (1st ed., pp. 365-435).
> Patakis.
>
> Hastrup, K. (1992). Writing ethnography: state of the art. In J.
> Okely, H. Callaway (Eds.). *Anthropology* *and* *Autobiography,* (pp.
> 327-345). Routledge.
>
> Howell, S. (2003). Kinning: The creation of life trajectories in
> transnational adoptive families. *Journal* *of* *the* *Royal*
> *Anthropological* *Institute*, *9*(3), 465-484.
>
> Kress, G. (2003). *Literacy* *in* *the* *New* *Media* *Age*.
> Routledge.
>
> Lambek, M. (1998). The Sakalava poiesis of history: realizing the past
> through spirit possession in Madagascar. *American* *Ethnologist,*
> 25(2), 106-127.
>
> Latour, B. (2012). *We* *have* *never* *been* *modern*. Harvard
> University Press.
>
> Longhurst, B., Smith, G., Bagnall, G., Crawford, G., & Ogborn, M.
> (2016). *Introducing* *cultural* *studies*. Taylor & Francis.
>
> Malinowski, B. (2002) \[1922\]. *Argonauts* *of* *the* *Western*
> *Pacific:* *An* *account* *of* *native* *enterprise* *and* *adventure*
> *in* *the* *archipelagoes* *of* *Melanesian* *New* *Guinea*.
> Routledge.
>
> Malinowski, B. (1989) \[1967\]. *A* *Diary* *in* *the* *Strict*
> *Sense* *of* *the* *Term* (Vol. 235). Stanford University Press.
>
> Manokha, Ivan. (2020). COVID-19: Teleworking, surveillance and 24/7
> work. Some reflexions on the expected growth of remote work after the
> pandemic. *Political* *Anthropological* *Research* *on*
> *International* *Social* *Sciences* *(PARISS)* 1(2), 273-287.
>
> Marcus, G. E., & Fischer, M. M. (2014). *Anthropology* *as* *cultural*
> *critique:* *An* *experimental* *moment* *in* *the* *human*
> *sciences*. University of Chicago Press.
>
> Mead, M., & Métraux, R. (Eds.). (2000) \[1953\]. *The* *study* *of*
> *culture* *at* *a* *distance* (Vol. 1). Berghahn Books.
>
> Mills, D., Ratcliffe, R. (2012). After method? Ethnography in the
> knowledge economy. *Qualitative* *Research*, *12*(2), 147-164.
>
> Price, D. H. (2016). *Cold* *War* *anthropology:* *The* *CIA,* *the*
> *Pentagon,* *and* *the* *growth* *of* *dual* *use* *anthropology*.
> Duke University Press.
>
> Thornton, R. J. (1985). 'Imagine Yourself Set Down...': Mach, Frazer,
> Conrad, Malinowski and the Role of Imagination in Ethnography.
> *Anthropology* *Today*, *1*(5), 7-14.
>
> Throop, C. J. (2003). Articulating experience. *Anthropological*
> *Theory*, *3*(2), 219-241.
>
> 95

*Teaching* *Anthropology* *2022,* *Vol.* *11,* *No.* *2,* *pp.* *86-96.*

> van der Geest, S., Gerrits, T., & Aaslid, F. S. (2012). Introducing
> 'Ethnography and Self- Exploration. *Medische* *Antropologie*, 24(1),
> 5-21.
> [<u>http://tma.socsci.uva.nl/24_1/intro.pdf</u>](http://tma.socsci.uva.nl/24_1/intro.pdf)
> .
>
> 96
